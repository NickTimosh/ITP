# Schema

## dependencies:
    - p7.js
    - p5 DOM

## html, css

## p5 app

- helpers:



## ColourPalette:

- public
- private


